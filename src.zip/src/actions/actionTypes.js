export const DETAIL_START = "DETAIL_START";
export const DETAIL_SUCCESS = "DETAIL_SUCCESS";
export const DETAIL_ERROR = "DETAIL_ERROR";
// Login
export const LOGIN_START = "LOGIN_START";
export const LOGIN_SUCCESS = "LOGIN_SUCCESS";
export const LOGIN_ERROR = "LOGIN_ERROR";
// Reset Password
export const RESET_PASSWORD_START = "RESET_PASSWORD_START";
export const RESET_PASSWORD_SUCCESS = "RESET_PASSWORD_SUCCESS";
export const RESET_PASSWORD_ERROR = "RESET_PASSWORD_ERROR";
// Snackbar
export const SET_SNACKBAR = "SET_SNACKBAR";
