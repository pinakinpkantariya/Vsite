import React, { Component } from "react";

import img1 from "../../images/logo.png";
import img2 from "../../images/v-logo.png";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import './index.scss';

class Home extends Component {
  render() {
    return (
      <Router>
      <section className="site-wapper">
        <nav className="site-nav open">
          <div className="inner-nav">
            <div className="company-logo">
              <div className="pic">
                <img src={img1} className="on-open" alt="logo" />{" "}
                <img src={img2} className="on-close" alt="logo" />
              </div>
            </div>
            <div className="profile">
              <span className="pic">
                <i className="icon-user-management"></i>
              </span>
              <span className="name">Mark Zuckerberg</span>
            </div>

            <ul className="menu-list">
              <li>
                <button>
                  <span className="icn-img">
                    <i className="icon-user"></i>
                  </span>
                  <span className="text">User Management</span>
                </button>
              </li>
              <li>
                <button>
                  <span className="icn-img">
                    <i className="icon-lander-management"></i>
                  </span>
                  <span className="text">Lender Management</span>
                </button>
              </li>
              <li>
                <button>
                  <span className="icn-img">
                    <i className="icon-call-configuration"></i>
                  </span>
                  <span className="text">Call Configuration</span>
                </button>
              </li>
              <li className="active">
                <button>
                  <span className="icn-img">
                    <i className="icon-profile-settings"></i>
                  </span>
                  <span className="text">Profile</span>
                </button>
              </li>
            </ul>
          </div>
          <div className="sign-out">
            <button>
              <i className="icon-signout"></i>
              <div className="sign-out-text">Sign Out</div>
            </button>
          </div>
        </nav>
        <main className="site-content">
          <header className="top-header">
            <div className="toggle-icon">
              <button>
                <i className="icon-hamburger-menu"></i>
              </button>
            </div>
          </header>
          {this.props.children}
          </main>
          </section>
      </Router>
    );
  }
}

export default Home;
